import React from 'react';    
import './App.css';
import PokemonPage from './Pages/PokemonPage';

function App() {
  return (
    <div className="App">
      <PokemonPage/>
      
    </div>
  );
}

export default App;
